#!/bin/python
from sys import argv 
from math import *
import numpy as np

def f(x1, x2):
    return (1.5-x1+x1*x2)**2+(2.25-x1+x1*x2**2)**2+(2.625-x1+x1*x2**3)**2

def c(x1, x2):
    return x1**2-x2

if __name__ == '__main__':
    x1 = float(argv[1])
    x2 = float(argv[2])
    print f(x1,x2)
    print c(x1,x2)
