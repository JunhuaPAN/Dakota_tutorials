#!/bin/sh
# Sample simulator to Dakota system call script
# See Advanced Simulation Code Interfaces chapter in Users Manual

# $1 is params.in FROM Dakota
# $2 is results.out returned to Dakota

# --------------
# PRE-PROCESSING
# --------------
# Incorporate the parameters from DAKOTA into the template, writing ros.in
# Use the following line if SNL's APREPRO utility is used instead of DPrePro.
# ../aprepro -c '*' -q --nowarning ros.template ros.in

dprepro $1 mesh.in.template mesh.in

# --------
# ANALYSIS : Run OpenFOAM
# --------

./Allrun

# ---------------
# POST-PROCESSING: Make results.out
# ---------------

# Do nothing because "results.out" generate in the OF run script
