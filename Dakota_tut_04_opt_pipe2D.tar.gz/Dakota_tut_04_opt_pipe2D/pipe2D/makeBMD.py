#!/usr/bin/python

# ---------------------------------- LICENCE  -------------------------------- %
#                                                                              %
#     Copyrighted 2014 by S. Wakashima, swaka@ichinoseki.ac.jp                 %
#                                                                              % 
#     This program is free software: you can redistribute it and/or modify     %
#     it under the terms of the GNU General Public License as published by     %
#     the Free Software Foundation, either version 3 of the License, or        %
#     (at your option) any later version.                                      %
#                                                                              %
#     This program is distributed in the hope that it will be useful,          %
#     but WITHOUT ANY WARRANTY; without even the implied warranty of           %
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            %
#     GNU General Public License for more details.                             %
#                                                                              %
#     You should have received a copy of the GNU General Public License        %
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.    %
#                                                                              %
#     Finally, if you add some useful functions for easy mesh generation,      %
#     please let me know and allow me to use them in this code :-)             %
# ---------------------------------------------------------------------------- %

# Usage:$ python makeBMD.py {x1} {x2} > constant/polyMesh/blockMeshDict  

import numpy as np
from math import *
import matplotlib.pyplot as plt
import sys # for get argv

################################################################################################

# Script args.
argv = sys.argv
argc = len(argv)
x1 = float(argv[1])
x2 = float(argv[2])

# Mesh dimensions
scale = 0.005;            # Scaling factor to "m"

# Mesh resolution parameters
N  = 20;              # Number of mesh cells across pipe
M  = [50,80,50];      # Number of mesh cells along pipe (block0, block1/Bezier, block2)
L  = 1;               # Number of cells in the z-direction
DZ = 1.0;             # thickness in the z-direction  

# Control for Bezier of bend 
offset = 5.0 
NV = [0,0,1]
P0 = [0,20,0]
P1 = [0,20+x1,0]
P2 = [20-x2,40,0]
P3 = [20,40,0]
P  = np.zeros((M[1]+1,3),dtype="float")
Poffset = np.zeros((2,M[1]+1,3),dtype="float")
GRD= np.zeros((M[1]+1,3),dtype="float")
length = 0.0
        
# vertex array
VXY = np.zeros((16,3),dtype="float")

# blocks array
blocks = np.zeros((3,8),dtype="int")

# edge array
edgeSE = np.zeros((4,2),dtype="int")
edges  = np.zeros((4,M[1]+1,3),dtype="float")

# patch(boundary face) array
patchs      = np.zeros((8,4),dtype="int")
emptypatchs = np.zeros((6,4),dtype="int")

################################################################################################

# vector fucntions
def rev(V):
    return -V

def abs(V):
    return sqrt(V[0]**2+V[1]**2+V[2]**2) 

def normalize(V):
    a = abs(V)
    if a == 0:
      print "Input is Zero Vector"
      return 
    else:
      return V[0]/a, V[1]/a, V[2]/a

def dot_product(V1,V2):
    return V1[0]*V2[0]+V1[1]*V2[1]+V1[2]*V2[2]

def cross_product(V1,V2):
    return V1[1]*V2[2]-V1[2]*V2[1], V1[2]*V2[0]-V1[0]*V2[2], V1[0]*V2[1]-V1[1]*V2[0]

# compute geometry functions
def setup_Bezier(P0,P1,P2,P3):
    
    ## Bezier points and tangiential vectors
    for i in range(M[1]+1):
        t = (1.0/M[1])*i

        w0 =   (1-t)**3
        w1 = 3*(1-t)**2 * t
        w2 = 3*(1-t)    * t**2
        w3 =              t**3

        dw0 = -3*(1-t)**2
        dw1 =  3*(1-t)*(1-3*t)
        dw2 =  3*t*(2-3*t)
        dw3 =  3*t**2

        x = w0*P0[0] + w1*P1[0] + w2*P2[0] + w3*P3[0]
        y = w0*P0[1] + w1*P1[1] + w2*P2[1] + w3*P3[1]
        z = w0*P0[2] + w1*P1[2] + w2*P2[2] + w3*P3[2]

        dx = dw0*P0[0] + dw1*P1[0] + dw2*P2[0] + dw3*P3[0]
        dy = dw0*P0[1] + dw1*P1[1] + dw2*P2[1] + dw3*P3[1]
        dz = dw0*P0[2] + dw1*P1[2] + dw2*P2[2] + dw3*P3[2]

        P[i][0], P[i][1], P[i][2] = x, y, z

        GRD[i][0], GRD[i][1], GRD[i][2] = dx, dy ,dz

        nx,ny,nz = normalize(cross_product(NV,[GRD[i][0],GRD[i][1],GRD[i][2]]))

        Poffset[0][i] = [ offset*nx+P[i][0], offset*ny+P[i][1], offset*nz+P[i][2]]
        Poffset[1][i] = [-offset*nx+P[i][0],-offset*ny+P[i][1],-offset*nz+P[i][2]]

    ## Bezier length
    length = 0
    for i in range(M[1]):
        length = length + sqrt((P[i+1][0]-P[i][0])**2+(P[i+1][1]-P[i][1])**2+(P[i+1][2]-P[i][2])**2)

    ## output length for file 
    f = open('results.out', 'w') 
    f.write(str(length)+"\n") 
    f.close()

    return

################################################################################################

def setup_mesh():

    # setup vertex 
    VXY[0][0], VXY[0][1], VXY[0][2] = -5, 0,0
    VXY[1][0], VXY[1][1], VXY[1][2] =  5, 0,0
    VXY[2][0], VXY[2][1], VXY[2][2] =  5,20,0
    VXY[3][0], VXY[3][1], VXY[3][2] = -5,20,0
    VXY[4][0], VXY[4][1], VXY[4][2] = 20,35,0
    VXY[5][0], VXY[5][1], VXY[5][2] = 20,45,0
    VXY[6][0], VXY[6][1], VXY[6][2] = 40,35,0
    VXY[7][0], VXY[7][1], VXY[7][2] = 40,45,0
    
    VXY[8][0] , VXY[8][1] , VXY[8][2]  = -5, 0,1
    VXY[9][0] , VXY[9][1] , VXY[9][2]  =  5, 0,1
    VXY[10][0], VXY[10][1], VXY[10][2] =  5,20,1
    VXY[11][0], VXY[11][1], VXY[11][2] = -5,20,1
    VXY[12][0], VXY[12][1], VXY[12][2] = 20,35,1
    VXY[13][0], VXY[13][1], VXY[13][2] = 20,45,1
    VXY[14][0], VXY[14][1], VXY[14][2] = 40,35,1
    VXY[15][0], VXY[15][1], VXY[15][2] = 40,45,1
    
    # make Blocks
    blocks[0] = [0,1,2,3,8,9,10,11]
    blocks[1] = [3,2,4,5,11,10,12,13]  
    blocks[2] = [5,4,6,7,13,12,14,15]  

    # make Edges(bend profiles)...allows BSpline/arc/line/polyLine/spline
    edgeSE[0] = [3,5]
    edgeSE[1] = [2,4]
    edgeSE[2] = [11,13]
    edgeSE[3] = [10,12]

    setup_Bezier(P0,P1,P2,P3)

    for i in range(M[1]+1):
        edges[0][i] = [Poffset[0][i][0],Poffset[0][i][1],0 ] 
        edges[1][i] = [Poffset[1][i][0],Poffset[1][i][1],0 ]
        edges[2][i] = [Poffset[0][i][0],Poffset[0][i][1],DZ]
        edges[3][i] = [Poffset[1][i][0],Poffset[1][i][1],DZ]

    # make Boundary Patchs
    ## inlet
    patchs[0] = [0,1,9,8]
    ## outlet
    patchs[1] = [6,7,15,14]
    ## upperWall
    patchs[2] = [3,0,8,11]
    patchs[3] = [5,3,11,13]
    patchs[4] = [7,5,13,15]
    ## lowerWall  
    patchs[5] = [1,2,10,9]
    patchs[6] = [2,4,12,10]
    patchs[7] = [4,6,14,12]

    # Empty patchs (frontAndBack)
    emptypatchs[0] = [0,3,2,1]
    emptypatchs[1] = [3,5,4,2]
    emptypatchs[2] = [5,7,6,4]
    emptypatchs[3] = [8,9,10,11]
    emptypatchs[4] = [11,10,12,13]
    emptypatchs[5] = [13,12,14,15]

    # make mergePatchpair
    # do nothing :-)

    return  

################################################################################################

# output fucntions
def makeHeader():
    print('/*--------------------------------*- C++ -*-----------------------------------*\\ ')
    print('| =========                 |                                                 | ')
    print('| \\\\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox           | ')
    print('|  \\\\    /   O peration     | Version:  2.3.0                                 | ')
    print('|   \\\\  /    A nd           | Web:      www.OpenFOAM.com                      | ')
    print('|    \\\\/     M anipulation  |                                                 | ')
    print('\\*----------------------------------------------------------------------------*/ ')
    print('FoamFile                                                                          ')
    print('{                                                                                 ')
    print('    version     2.0;                                                              ')
    print('    format      ascii;                                                            ')
    print('    class       dictionary;                                                       ')
    print('    object      blockMeshDict;                                                    ')
    print('}                                                                                 ')
    print('// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * // ')
    print('');
    return

def makeConvertToMeters(scale):
    print 'convertToMeters %f; ' % scale
    print('')
    return

def makeVertices():    
    print('vertices')
    print('(')
    for i in range(16):
        print "    ( %f %f %f )" % (VXY[i][0], VXY[i][1], VXY[i][2])
    print(');')
    print('')
    return

def makeBlocks(): 
    print('blocks')
    print('(')
    for i in range(3):
        blist = ( blocks[i][0], blocks[i][1], blocks[i][2], blocks[i][3], 
                  blocks[i][4], blocks[i][5], blocks[i][6], blocks[i][7],
                  N, M[i], L)  
        print "    hex ( %d %d %d %d %d %d %d %d ) (%d %d %d) simpleGrading (1 1 1)" % blist
    print(');')
    print('')
    return

def makeEdges():
    print('edges')
    print('(')
    for i in range(4):
        elist = ( edgeSE[i][0], edgeSE[i][1] )
        print "   BSpline  %d %d ( " % elist,
        for j in range(1,M[1]+1):
            elist = ( edges[i][j][0], edges[i][j][1], edges[i][j][2] )
            print "( %f %f %f )" % elist,
        print " )"
    print(');')
    print('')
    return
      
def makeBoundary():
    print('boundary')
    print('(')   
    
    print "  inlet"
    print "  {"
    print "     type patch;"
    print "     faces"
    print "     ("
    for i in range(1):
            plist = ( patchs[i][0], patchs[i][1], patchs[i][2], patchs[i][3] )
            print "          ( %d %d %d %d )" % plist
    print "     );"
    print "  }"

    print "  outlet"
    print "  {"
    print "     type wall;"
    print "     faces"
    print "     ("
    for i in range(1,2):
            plist = ( patchs[i][0], patchs[i][1], patchs[i][2], patchs[i][3] )
            print "          ( %d %d %d %d )" % plist
    print "     );"
    print "  }"

    print "  upperWall"
    print "  {"
    print "     type wall;"
    print "     faces"
    print "     ("
    for i in range(2,5):
            plist = ( patchs[i][0], patchs[i][1], patchs[i][2], patchs[i][3] )
            print "          ( %d %d %d %d )" % plist
    print "     );"
    print "  }"

    print "  lowerWall"
    print "  {"
    print "     type wall;"
    print "     faces"
    print "     ("
    for i in range(5,8):
            plist = ( patchs[i][0], patchs[i][1], patchs[i][2], patchs[i][3] )
            print "          ( %d %d %d %d )" % plist
    print "     );"
    print "  }"
    
    print "  frontAndBack"
    print "  {"
    print "     type empty;"
    print "     faces"
    print "     ("
    for i in range(6):
            plist = ( emptypatchs[i][0], emptypatchs[i][1], emptypatchs[i][2], emptypatchs[i][3] )
            print "          ( %d %d %d %d )" % plist
    print "     );"
    print "  }"
    
    print(');')
    print('')
    return

def makeMergePatchPairs():
    print('mergePatchPairs')
    print('(')
    print(');')
    print('')
    return

# Just main fucntion
def main():

    # setup blockmesh
    setup_mesh()

    # output blockMeshDict
    makeHeader()

    makeConvertToMeters(scale)

    makeVertices()

    makeBlocks()

    makeEdges()

    makeBoundary()

    makeMergePatchPairs()

if __name__ == '__main__':
    main()
