#!/bin/sh

rm -rf results.out
rm -rf [1-9] [1-9]*
rm -rf postProcessing
