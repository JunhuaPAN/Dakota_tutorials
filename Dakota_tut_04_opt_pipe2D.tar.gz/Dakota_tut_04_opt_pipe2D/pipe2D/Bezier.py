#!/usr/bin/python

import numpy as np
from math import *
import matplotlib.pyplot as plt
import sys # for get argv

################################################################################################

# Script args.
argv = sys.argv
argc = len(argv)
x1 = float(argv[1])
x2 = float(argv[2])

# Control for Bezier of bend 
offset = 5.0 
N = 20
NV = [0,0,1]
P0 = [0,20,0]
P1 = [0,20+x1,0]
P2 = [20-x2,40,0]
P3 = [20,40,0]
#print x1,x2

P  = np.zeros((N+1,3),dtype="float")
GRD= np.zeros((N+1,3),dtype="float")
        

# vector fucntions
def rev(V):
    return -V

def abs(V):
    return sqrt(V[0]**2+V[1]**2+V[2]**2) 

def normalize(V):
    a = abs(V)
    if a == 0:
      print "Input is Zero Vector"
      return 
    else:
      return V[0]/a, V[1]/a, V[2]/a

def dot_product(V1,V2):
    return V1[0]*V2[0]+V1[1]*V2[1]+V1[2]*V2[2]

def cross_product(V1,V2):
    return V1[1]*V2[2]-V1[2]*V2[1], V1[2]*V2[0]-V1[0]*V2[2], V1[0]*V2[1]-V1[1]*V2[0]

# compute geometry functions
def setup_Bezier(N,P0,P1,P2,P3):
    
    ## Bezier points and tangiential vectors
    for i in range(N+1):
        t = (1.0/N)*i

        w0 =   (1-t)**3
        w1 = 3*(1-t)**2 * t
        w2 = 3*(1-t)    * t**2
        w3 =              t**3

        dw0 = -3*(1-t)**2
        dw1 =  3*(1-t)*(1-3*t)
        dw2 =  3*t*(2-3*t)
        dw3 =  3*t**2

        x = w0*P0[0] + w1*P1[0] + w2*P2[0] + w3*P3[0]
        y = w0*P0[1] + w1*P1[1] + w2*P2[1] + w3*P3[1]
        z = w0*P0[2] + w1*P1[2] + w2*P2[2] + w3*P3[2]

        dx = dw0*P0[0] + dw1*P1[0] + dw2*P2[0] + dw3*P3[0]
        dy = dw0*P0[1] + dw1*P1[1] + dw2*P2[1] + dw3*P3[1]
        dz = dw0*P0[2] + dw1*P1[2] + dw2*P2[2] + dw3*P3[2]

        nx,ny,nz = normalize(cross_product(NV,[dx,dy,dz]))

        print i,x,y,z,dx,dy,dz,nx,ny,nz

        P[i][0], P[i][1], P[i][2] = x, y, z
        GRD[i][0], GRD[i][1], GRD[i][2] = dx, dy ,dz

    # Bezier length
    length = 0
    for i in range(N):
        length = length + sqrt((P[i+1][0]-P[i][0])**2+(P[i+1][1]-P[i][1])**2+(P[i+1][2]-P[i][2])**2)

    return 

if __name__ == '__main__':
    setup_Bezier(N,P0,P1,P2,P3)
