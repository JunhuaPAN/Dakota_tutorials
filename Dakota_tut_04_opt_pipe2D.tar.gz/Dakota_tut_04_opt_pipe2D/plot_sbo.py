import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

x1,x2=[],[]
f1,f2,f3=[],[],[]
for line in open('finaldata10.dat','r').readlines():
    items = line.split()
    if(items[0].startswith("%")):
      continue
    else:
      x1 += [float(items[0])]
      x2 += [float(items[1])]
      f1 += [float(items[2])]
      f2 += [float(items[3])]
      f3 += [float(items[4])]


# scatter 3D plot
fig1 = plt.figure()
ax1 = Axes3D(fig1)
ax1.scatter(x1, x2, f1, c=f1, s=40)
ax1.set_xlabel('x1')
ax1.set_ylabel('x2')
ax1.set_zlabel('f1')
ax1.set_xlim3d(6,18)
ax1.set_ylim3d(6,18)
ax1.set_zlim3d(29.5,34.5)

fig2 = plt.figure()
ax2 = Axes3D(fig2)
ax2.scatter(x1, x2, f2, c=f2, s=40)
ax2.set_xlabel('x1')
ax2.set_ylabel('x2')
ax2.set_zlabel('f2')
ax2.set_xlim3d(6,18)
ax2.set_ylim3d(6,18)
ax2.set_zlim3d(6, 9)

fig3 = plt.figure()
ax3 = Axes3D(fig3)
ax3.scatter(x1, x2, f3, c=f3, s=40)
ax3.set_xlabel('x1')
ax3.set_ylabel('x2')
ax3.set_zlabel('f3')
ax3.set_xlim3d(6,18)
ax3.set_ylim3d(6,18)

fig4 = plt.figure()
ax4 = Axes3D(fig4)
scaledf1 = f1/np.amax(f1)
scaledf2 = f2/np.amax(f2)
scaledf3 = f3/np.amax(f3)
ax4.scatter(scaledf1, scaledf2, scaledf3, s=40)
ax4.set_xlabel('scaled f1')
ax4.set_ylabel('scaled f2')
ax4.set_zlabel('scaled f3')

plt.show()

