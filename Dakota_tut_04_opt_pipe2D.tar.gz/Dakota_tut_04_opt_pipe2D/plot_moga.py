import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

x1,x2=[],[]
f1,f2,f3=[],[],[]
for line in open('objective.dat','r').readlines():
    items = line.split()
    if(items[0].startswith("%")):
      continue
    else:
      x1 += [float(items[2])]
      x2 += [float(items[3])]
      f1 += [float(items[4])]
      f2 += [float(items[5])]
      f3 += [float(items[6])]


# scatter 3D plot
fig1 = plt.figure()
ax1 = Axes3D(fig1)
ax1.scatter(x1, x2, f1, c=f1, s=40)
ax1.set_xlabel('x1')
ax1.set_ylabel('x2')
ax1.set_zlabel('f1')

fig2 = plt.figure()
ax2 = Axes3D(fig2)
ax2.scatter(x1, x2, f2, c=f2, s=40)
ax2.set_xlabel('x1')
ax2.set_ylabel('x2')
ax2.set_zlabel('f2')

fig3 = plt.figure()
ax3 = Axes3D(fig3)
ax3.scatter(x1, x2, f3, c=f3, s=40)
ax3.set_xlabel('x1')
ax3.set_ylabel('x2')
ax3.set_zlabel('f3')

plt.show()

