#!/bin/python
from sys import argv 
from math import *
import numpy as np

def f1(x1, x2):
    return 2.0*sqrt(x1)

def f2(x1, x2):
    return x1-x1*x2+5.0

if __name__ == '__main__':
    x1 = float(argv[1])
    x2 = float(argv[2])
    print f1(x1,x2), f2(x1,x2)
